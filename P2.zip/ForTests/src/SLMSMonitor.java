import java.util.Queue;

public class SLMSMonitor implements TurnMonitor {
	private int twt,ase,tcb;
	Queue<Customer> toServe, served;
	
	public SLMSMonitor(Queue<Customer> custs) {
		toServe = custs;
		served = new Queue<Customer>();
		
	}

	@Override
	public void monitor() {
		// TODO Auto-generated method stub
		
	}
}
