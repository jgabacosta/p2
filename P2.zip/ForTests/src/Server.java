import java.util.Queue;

public class Server {
	private Queue<Customer> toServe, served;
	private int free;
	
	public Server(Queue<Customer> c,Queue<Customer> done) {
		this.toServe = c;
		this.served = done;
	}
	
	public int getFree() {
		return free;
	}
	
	public void serve(int time) {
		Customer t = toServe.remove();
		free = time + t.getServT();
	}
	
	
	

}
