
public class Customer {
	private int arrT,servT;
	
	public Customer(int arrT, int servT) {
		this.arrT = arrT;
		this.servT = servT;
	}

	public int getArrT() {
		return arrT;
	}

	public int getServT() {
		return servT;
	}
	
	

}
