
public interface TurnMonitor {

	public void monitor();
}
